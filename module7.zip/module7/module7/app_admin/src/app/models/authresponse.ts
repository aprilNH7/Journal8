export class AuthResponse {
  token!: FunctionStringCallback;
}
